# coding: utf8
from __future__ import unicode_literals
from .neuralcoref import NeuralCoref

__all__ = ['NeuralCoref']